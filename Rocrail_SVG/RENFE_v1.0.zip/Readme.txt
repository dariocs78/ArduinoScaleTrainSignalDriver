-- SVGs for RENFE/ADIF signals in Rocrail format
-- Based on "signalaspect-n.svg" default set in Rocrail
-- v1.0 - Dario Calvo Sanchez, 2021 - Web: elgajoelegante.com - Twitter: @DarioCalvoS

Licensed under CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1)



********************************
 REQUIREMENTS
********************************

- Rocrail (version 2.1.1529 or higher)
- Command station and decoders with "Signal Packet" multiaspect signal support



********************************
 INSTALL
********************************

1- Copy this folder into "/svg/themes/" Rocrail installation folder
2- Create signals in Rocrail and edit properties as follows:
2.1 - On "Interface" sleeve, check "Aspect number" type and "Accessory" marks
2.2 - Assign "RED" address only as a single DCC address for the whole signal, using "Port" value 1
2.3 - Configure parameters on "Details" sleeve, using details below (prefix, aspects, aspect names...)
3 - If the signal has any blinking aspect, right-click on the signal and select "Enable alternative SVG"


********************************
 SIGNAL TYPES
********************************

 Color code:
   G: Green
   R: Red
   Y: Yellow
   W: White
   B: Blue

=============================================================================
 RENFE/ADIF 2-light main or dwarf signal (G/R)
=============================================================================
- Prefix: rn_s2_1-
- 4 aspects: Stop, Proceed, Proceed on condition, Signal off
- Requires "Enable alternative SVG" function for blinking

=============================================================================
 RENFE/ADIF 2-light distant signal (G/Y)
=============================================================================
- Prefix: rn_s2_2-
- 6 aspects: Immediate stop warning, Proceed, Proceed on condition, Precaution warning, Stop warning, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 2-light entrance signal (R/Y)
=============================================================================
- Prefix: rn_s2_3-
- 4 aspects: Stop, Stop warning, Immediate stop warning, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 2-light dwarf signal (R/W)
=============================================================================
- Prefix: rn_s2_4-
- 5 aspects: Stop, Authorized pass (stopping on signal), Authorized pass (no stopping on signal), Authorized movement, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 2-light dwarf signal (R/R)
=============================================================================
- Prefix: rn_s2_5-
- 2 aspects: Stop, Signal off
- Does not require blinking configuration


=============================================================================
 RENFE/ADIF 3-light main or dwarf signal (G/R/Y)
=============================================================================
- Prefix: rn_s3_1-
- 7 aspects: Stop, Proceed, Proceed on condition, Precaution warning, Stop warning, Immediate stop warning, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 3-light departure signal (G/R/W)
=============================================================================
- Prefix: rn_s3_2-
- 7 aspects: Stop, Proceed, Proceed on condition, Authorized pass (stopping on signal), Authorized pass (no stopping on signal), Authorized movement, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 4-light departure signal (G/R/Y/W)
=============================================================================
- Prefix: rn_s4_1-
- 10 aspects: Stop, Proceed, Proceed on condition, Precaution warning, Stop warning, Immediate stop warning, Authorized pass (stopping on signal), Authorized pass (no stopping on signal), Authorized movement, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 4-light departure signal (G/R/Y/B)
=============================================================================
- Prefix: rn_s4_2-
- 10 aspects: Stop, Proceed, Proceed on condition, Precaution warning, Stop warning, Immediate stop warning, Selective stop, Selective stop (with blinking blue light), Authorized movement, Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 4-light dwarf direction indicator & entry signal (R/3W) - Left
=============================================================================
- Prefix: rn_dir_1-
- 7 aspects: Stop, Authorized pass (stopping on signal), Authorized pass (no stopping on signal), Authorized movement, Switch entrance indication (straight track), Switch entrance indication (diverging track), Signal off
- Requires "Enable alternative SVG" function for blinking


=============================================================================
 RENFE/ADIF 4-light dwarf direction indicator & entry signal (R/3W) - Right
=============================================================================
- Prefix: rn_dir_2-
- 7 aspects: Stop, Authorized pass (stopping on signal), Authorized pass (no stopping on signal), Authorized movement, Switch entrance indication (straight track), Switch entrance indication (diverging track), Signal off
- Requires "Enable alternative SVG" function for blinking